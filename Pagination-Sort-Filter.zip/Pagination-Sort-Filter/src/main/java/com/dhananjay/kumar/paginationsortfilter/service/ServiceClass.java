package com.dhananjay.kumar.paginationsortfilter.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceClass {
}
