package com.dhananjay.kumar.paginationsortfilter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginationSortFilterApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaginationSortFilterApplication.class, args);
    }

}
