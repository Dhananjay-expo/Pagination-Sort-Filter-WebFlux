package com.dhananjay.kumar.paginationsortfilter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginationSortFilterApplicationTests {

    @Test
    void contextLoads() {
    }

}
